<?php 
// session_start()
?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Home Admin</title>
	<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/styleku.css">
		<link rel="stylesheet" href="bootstrap513/css/bootstrap.min.css">
		<script src="bootstrap513/js/bootstrap.js"></script>
		<script src="bootstrap513/jquery/jquery-3.3.1.js"></script>
</head>
<body>
<?php
//memanggil file berisi fungsi2 yang sering dipakai
require "fungsi.php";
require "head.html";

//cek logout
// if (!isset($_SESSION['username'])){
	if (['username']){
	header("location:index1.php");
}
?>
<div class="utama">
	<br><br>
	<h1 class="text-center">Selamat Datang di Halaman Administrator saudara <?php echo strtoupper(['username'])?></h1>
	<!-- h1 class="text-center">Selamat Datang di Halaman Administrator saudara //< ?php echo strtoupper($_SESSION['username'])?></h1 -->
</div>
</body>
</html>	
