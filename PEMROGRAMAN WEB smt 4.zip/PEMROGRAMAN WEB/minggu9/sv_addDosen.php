<?php
    include "fungsi.php"; // masukan konekasi DB

    // ambil variable
    $npp=$_POST['npp'];
    $nama=$_POST['namadosen'];
    $homebase=$_POST["homebase"];

    // default sukses unggah foto 
    $simpan=mysqli_query($koneksi,"insert into dosen (npp,namadosen,homebase) values ('$npp','$nama','$homebase')");
if($simpan){
    echo "Data berhasil disimpan: <a href='addDosen.php'> </a>";
    require "addDosen.php";
}else{
    echo "Gagal simpan data!";
}
?>