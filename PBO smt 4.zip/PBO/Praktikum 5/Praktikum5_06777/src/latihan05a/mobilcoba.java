package latihan05a;

public class mobilcoba {
    public static void main(String[] args) {
        mobil toyota01 = new mobil();
        
        toyota01.setModel("Avanza");
        toyota01.setSpeed(120);
        
        System.out.print("Mobil : " + toyota01.getModel());
        System.out.print(" Mempunyai maxSpeed " + toyota01.getSpeed() );
        System.out.print("km per jam\n");
    }
}
