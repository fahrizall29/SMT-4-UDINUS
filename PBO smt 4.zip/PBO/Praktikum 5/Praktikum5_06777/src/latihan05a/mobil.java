package latihan05a;

public class mobil {
    //property...................................
    private String model;
    private int maxSpeed;
    
    //behavior...................................
    public void setModel(String param1) {
        
        model = param1;
        
    }
    public void setSpeed(int param2)
    {
        maxSpeed = param2;
    }
    public String getModel()
    {
        return model;
    }
    public int getSpeed()
    {
        return maxSpeed;
    } 
}
