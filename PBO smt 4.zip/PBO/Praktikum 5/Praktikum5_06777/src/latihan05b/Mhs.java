package latihan05b;

public class Mhs 
{
    //property............................
    private String nama;
    private float ipk;
    
    //behavior............................
    public void setNama(String nama)
    {
        this.nama = nama;
    }
    
    public void seIpk(int ipk)
    {
        this.ipk = ipk;
    }
    
    public String getNama()
    {
        return this.nama;
    }
}

