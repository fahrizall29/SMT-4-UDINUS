package latihan05b;

public class cobaMhs {
    public static void main(String[] args)
    {
        Mhs mhsAdi = new Mhs();
        mhsAdi.setNama("Adi Sanjaya");
        System.out.print("Nama Mhs : " + mhsAdi.getNama());
    }
}

