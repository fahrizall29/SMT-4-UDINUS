public class Latihan2c {
    public static void main(String[] args) {
        String angka = "1010";
        int angka2 = Integer.valueOf(angka);
        
        System.out.println(angka + 10);
        System.out.println(angka2 + 10);
    }
}
