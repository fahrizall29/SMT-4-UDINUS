public class Latihan2g {
    public static void main(String[] args) {
        double[] myList = {1.1, 2, 3, 4, 5};
        double total = 0;
        
        for (double value : myList) {
            total = total + value;
        }
        System.out.println(total);
    }
}