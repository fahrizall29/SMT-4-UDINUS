public class Latihan2h {
    public static void main(String[] args) {
        double myDouble = 9.78;
        double myInt = myDouble;
        
        System.out.println(myDouble);
        System.out.println(myInt);
    }
    
}
