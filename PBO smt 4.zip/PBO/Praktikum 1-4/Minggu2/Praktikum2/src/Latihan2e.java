public class Latihan2e {
    public static void main(String[] args) {
        int a, t;
        double luas;
        
        a = 2; t = 7;
        
        luas = 0.5 * a * t;
        
        System.out.println("Luas segitiga : " + luas);
    }
    
}
