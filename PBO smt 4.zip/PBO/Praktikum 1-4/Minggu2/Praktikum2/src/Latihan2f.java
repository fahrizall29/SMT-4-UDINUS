public class Latihan2f {
    public static void main(String[] args) {
        double[] myList = {1.1, 2, 3, 4, 5};
        for (int i = 0; i < myList.length; i++)
        {
        System.out.println(myList[i]);
        }
    }
}