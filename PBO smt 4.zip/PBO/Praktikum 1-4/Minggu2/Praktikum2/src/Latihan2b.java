public class Latihan2b {
    public static void main(String[] args) {
        int value = 10;
        char x;
        x = 'A';
        
        System.out.println(value);
        System.out.print("The value of x = " + x );
    }
}
