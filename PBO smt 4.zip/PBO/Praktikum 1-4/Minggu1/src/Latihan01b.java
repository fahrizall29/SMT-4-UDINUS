public class Latihan01b {
public static void main (String[] args)
    {
        System.out.println("Hello Guys");
        System.out.println("Nama : Nama Saya Siapa");
        System.out.println("Jenis Kelamin : Laki-Laki");
        System.out.println("Alamat : Jl. Pisang");
        System.out.println("Kota : Semarang");
        System.out.println("Telepon : 0897654321");
    }
}
