public class Latihan01a {
public static void main (String[] args)
    {
        System.out.println("Hello Java");
    }
}
