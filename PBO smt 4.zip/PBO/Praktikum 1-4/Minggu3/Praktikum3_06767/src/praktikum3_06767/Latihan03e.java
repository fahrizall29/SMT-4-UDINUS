package praktikum3_06767;

public class Latihan03e {
    public static void main(String[] args) {
        int a = 8;
        int b = 20;
        
        System.out.println("Nilai a : " + ( a ));
        System.out.println("Nilai b : " + ( b ));
        System.out.println("Hasil a>>1 : " + ( a>>1 ));
        System.out.println("Hasil a>>2 : " + ( a>>2 ));
        System.out.println("Hasil b<<1 : " + ( b<<1 ));
        System.out.println("Hasil b<<2 : " + ( b<<2 ));
        
        System.out.println("\n=====================");
        System.out.println("Program : Latihan03e");
        System.out.println("NIM     : A12.2022.06767");
        System.out.println("NAMA    : Mukhlis Amin");
    }
}
