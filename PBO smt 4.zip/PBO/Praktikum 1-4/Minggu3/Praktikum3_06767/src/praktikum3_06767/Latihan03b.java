package praktikum3_06767;

public class Latihan03b {
    public static void main(String[] args) {
        int a, hasil;
        a = 14;
        hasil = (a++ > 14) ? 10 : 20;
        System.out.println("Output Satu : " + hasil);
        
        hasil = (a <= 14) ? 30 : 40;
        System.out.println("Output Dua : " + hasil);
        
        hasil = (a > 14 && a < 45) ? 50 : 60;
        System.out.println("Output Tiga : " + hasil);
        
        hasil = (a < 14 || a < 45) ? 70 : 80;
        System.out.println("Output Empat : " + hasil);
        
        System.out.println("\n=====================");
        System.out.println("Program : Latihan03b");
        System.out.println("NIM     : A12.2022.06767");
        System.out.println("NAMA    : Mukhlis Amin");

    }
}
