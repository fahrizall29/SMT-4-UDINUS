package praktikum3_06767;

public class Latihan03f {
    public static void main(String[] args) {
        int a = 8;
        int b = 10;
        
        System.out.println("Nilai a : " + ( a ));
        System.out.println("Nilai b : " + ( b ));
        System.out.println("a++ : " + ( a++ ));
        System.out.println("++b : " + ( ++b ));
        System.out.println("a++ + ++a : " + ( a++ + ++a ));
        System.out.println("b++ + b++ : " + ( b++ + b++ ));
        
        System.out.println("\n=====================");
        System.out.println("Program : Latihan03f");
        System.out.println("NIM     : A12.2022.06767");
        System.out.println("NAMA    : Mukhlis Amin");
    }
    
}
