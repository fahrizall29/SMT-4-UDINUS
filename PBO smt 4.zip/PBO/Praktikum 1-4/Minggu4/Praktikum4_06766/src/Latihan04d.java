/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author D2K
 */
import java.util.Scanner;
public class Latihan04d {
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        String nama,noPel;
        int air, harga, total=0;
        
        System.out.println("Perhitungan Biaya Pemakaian Air");
        System.out.println("=====================================");
        System.out.println("Hitung Total Penjualan");
        System.out.print("Nama          :");
        nama = input.nextLine();
        System.out.print("No. Pelanggan :");
        noPel = input.nextLine();
        System.out.print("Pemakaian Air :");
        air = input.nextInt();
        
        for(int i = 1; 1 <= air; i++){
         if (i <= 10){
                harga = 1000;
                total += harga;
            }
            else if (i > 10 && i<=20){
                harga = 2000;
                total += harga;
            }
            else {
                harga = 5000;
                total += harga;
            }   
        }
        System.out.print("Biaya Pakai :" + total);
    }
}
