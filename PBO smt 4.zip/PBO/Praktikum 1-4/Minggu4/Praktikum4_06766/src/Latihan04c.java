/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author D2K
 */
import java.util.Scanner;
public class Latihan04c {
    public static void main(String[] args)
    {
        String nama, nilaiHuruf;
        int nilai;
        Scanner oscan01 = new Scanner(System.in);
        System.out.println("Data Test ");
        System.out.println("========================");
        System.out.print("Nama          :");
        nama = oscan01.nextLine();
        System.out.print("Program Studi :");
        nama = oscan01.nextLine();
        System.out.print("Nilai         :");
        nilai = oscan01.nextInt();
    
        //Hitung Konversi Nilai Huruf
       if (nilai >= 85){
           nilaiHuruf = "A";
       }
       else if (nilai >= 70 && nilai < 85){
           nilaiHuruf = "B";
       }
       else if (nilai >= 60 && nilai < 70){
           nilaiHuruf = "C";
       }
       else if (nilai >= 50 && nilai < 60){
           nilaiHuruf = "D";
       }
       else {
           nilaiHuruf = "E";
       }
       System.out.println("Nilai Huruf   :" + nilaiHuruf);
    }
}