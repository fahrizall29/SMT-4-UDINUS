public class PesertaBaru extends Peserta {
    private double diskon;
    private double harga;

    public PesertaBaru(String kode, String nama, String telp, String email, String alamat, int jenis) {
        super(kode, nama, telp, email, alamat, jenis);
        this.diskon = getDiskon();
        this.harga = biaya - diskon;
    }

    public double getDiskon() {
        return (jenis.equals("Udinus")) ? 0.20 * biaya : 0.10 * biaya;
    }

    public double getDiskon(double harga) {
        return (jenis.equals("Udinus")) ? 0.20 * harga : 0.10 * harga;
    }

    @Override
    public void cetakPeserta() {
        super.cetakPeserta();
        System.out.println("Diskon\t\t: " + (int) (getDiskon() * 100) + "%");
        System.out.println("Harga Total\t: Rp. " + harga);
    }
}
