public class Peserta {
    protected String kode, nama, telp, email, alamat, jenis, deskripsi;
    protected double biaya;

    public Peserta(String kode, String nama, String telp, String email, String alamat, int jenis) {
        this.kode = kode;
        this.nama = nama;
        this.telp = telp;
        this.email = email;
        this.alamat = alamat;
        this.jenis = getJenisPeserta(jenis);
        this.deskripsi = getDeskripsi(jenis);
        this.biaya = getBiaya(jenis);
    }

    public String getJenisPeserta(int jenis) {
        return (jenis == 1) ? "Udinus" : "Luar Udinus";
    }

    public String getDeskripsi(int jenis) {
        return (jenis == 1) ? "Peserta dari Udinus" : "Peserta dari luar Udinus";
    }

    public double getBiaya(int jenis) {
        return (jenis == 1) ? 150000.00 : 200000.00;
    }

    public void cetakPeserta() {
        System.out.println("Kode Peserta\t: " + kode);
        System.out.println("Nama\t\t: " + nama);
        System.out.println("Email\t\t: " + email);
        System.out.println("Telp/HP\t\t: " + telp);
        System.out.println("Alamat\t\t: " + alamat);
        System.out.println("Jenis Peserta\t: " + jenis);
        System.out.println("Deskripsi\t: " + deskripsi);
        System.out.println("Biaya\t\t: Rp. " + biaya);
    }
}
