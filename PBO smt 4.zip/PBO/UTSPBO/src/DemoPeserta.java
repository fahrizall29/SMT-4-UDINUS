import java.util.Scanner;

public class DemoPeserta {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Registrasi Seminar Mahasiswa 2024");
        System.out.println("=================================");
        System.out.print("Kode Peserta\t: ");
        String kode = input.nextLine();
        System.out.print("Nama\t\t: ");
        String nama = input.nextLine();
        System.out.print("Email\t\t: ");
        String email = input.nextLine();
        System.out.print("No HP\t\t: ");
        String telp = input.nextLine();
        System.out.print("Alamat\t\t: ");
        String alamat = input.nextLine();
        System.out.print("Jenis Peserta [1/2]\t: ");
        int jenis = input.nextInt();

        PesertaBaru peserta = new PesertaBaru(kode, nama, telp, email, alamat, jenis);
        System.out.println("\nRegistrasi Seminar Mahasiswa 2024");
        System.out.println("=================================");
        peserta.cetakPeserta();
    }
}
