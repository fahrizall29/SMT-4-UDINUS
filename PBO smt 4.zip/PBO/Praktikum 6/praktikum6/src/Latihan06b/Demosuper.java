/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Latihan06b;

/**
 *
 * @author D2K
 */
 public class Demosuper {
    public static void main(String[] args) {
        Employee dian = new Employee();
        
        dian.showInfo();
    }
}
