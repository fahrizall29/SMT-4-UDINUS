/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Latihan06a;

/**
 *
 * @author D2K
 */
class TestInheri01 {
        public static void main(String args[])
        {
            Programmer p = new Programmer ();
            System.out.println("Programmer salary is     : " + p.salary);
            System.out.println("Bonus of Programmer is   : " + p.bonus);
        }
}